"""
Online Hospital Bed-Allocation Policy Benchmark
Evaluation Script with Exact NumPy PCG64 Reproducibility
Seed: 20260911
"""

import numpy as np
import heapq
from typing import List, Optional, Dict

SEED = 20260911
TOTAL_PATIENTS = 500
MEAN_INTERARRIVAL = 2.5
ACUITY_PROBS = [0.60, 0.30, 0.10]
CAPACITIES = {'general': 30, 'monitored': 10, 'critical': 5}
STAY_SIGMA = 0.35
STAY_MEDIANS = {'general': 120.0, 'monitored': 180.0, 'critical': 240.0}
WEIGHTS = {1: 1.0, 2: 3.0, 3: 8.0}
MAX_WAIT_CAP = 240.0

class OnlineBedPolicy:
    """Non-anticipative online policy with dynamic opportunity-cost reservation."""
    def __init__(self):
        self.crit_reserve = 1
        self.mon_reserve = 2

    def decide_allocation(self, patient, free_beds: Dict[str, int], queue: List, current_time: float) -> Optional[str]:
        acuity = patient.acuity
        wait = current_time - patient.arrival_time

        if acuity == 3:
            return 'critical' if free_beds['critical'] > 0 else None

        if acuity == 2:
            if free_beds['monitored'] > 0:
                return 'monitored'
            has_waiting_crit = any(p.acuity == 3 for p in queue)
            if not has_waiting_crit and free_beds['critical'] > self.crit_reserve:
                return 'critical'
            elif not has_waiting_crit and free_beds['critical'] > 0 and wait > 50.0:
                return 'critical'
            return None

        if acuity == 1:
            if free_beds['general'] > 0:
                return 'general'
            has_waiting_high = any(p.acuity >= 2 for p in queue)
            if not has_waiting_high and free_beds['monitored'] > self.mon_reserve and wait > 60.0:
                return 'monitored'
            return None

        return None

    def priority_score(self, patient, current_time: float) -> float:
        wait = min(current_time - patient.arrival_time, MAX_WAIT_CAP)
        urgency = 3.0 if wait > 200.0 else (1.5 if wait > 120.0 else 1.0)
        return WEIGHTS[patient.acuity] * wait * urgency

def run_simulation(seed: int = SEED) -> Dict[str, float]:
    rng = np.random.default_rng(seed)
    policy = OnlineBedPolicy()

    interarrivals = rng.exponential(scale=MEAN_INTERARRIVAL, size=TOTAL_PATIENTS)
    arrivals = np.cumsum(interarrivals)
    acuities = rng.choice([1, 2, 3], size=TOTAL_PATIENTS, p=ACUITY_PROBS)

    hidden_stays = {
        'general': rng.lognormal(mean=np.log(STAY_MEDIANS['general']), sigma=STAY_SIGMA, size=TOTAL_PATIENTS),
        'monitored': rng.lognormal(mean=np.log(STAY_MEDIANS['monitored']), sigma=STAY_SIGMA, size=TOTAL_PATIENTS),
        'critical': rng.lognormal(mean=np.log(STAY_MEDIANS['critical']), sigma=STAY_SIGMA, size=TOTAL_PATIENTS)
    }

    beds = {bt: [None] * cap for bt, cap in CAPACITIES.items()}
    free_beds = CAPACITIES.copy()
    queue = []
    events = []

    records = []
    for i in range(TOTAL_PATIENTS):
        records.append({
            'id': i,
            'arrival_time': arrivals[i],
            'acuity': acuities[i],
            'weight': WEIGHTS[acuities[i]],
            'wait': 0.0,
            'status': 'SCHEDULED',
            'assigned_bed': None
        })

    heapq.heappush(events, (arrivals[0], 'ARRIVAL', 0))

    sim_time = 0.0
    avoidable_specialized = 0
    admitted_count = 0
    rejected_count = 0
    next_arr_idx = 1

    def attempt_allocations(cur_t):
        nonlocal avoidable_specialized, admitted_count
        if not queue:
            return
        queue.sort(key=lambda p: policy.priority_score(p, cur_t), reverse=True)
        unassigned = []
        for p in queue:
            chosen_bed = policy.decide_allocation(p, free_beds, queue, cur_t)
            if chosen_bed and free_beds[chosen_bed] > 0:
                if p.acuity == 1 and chosen_bed in ('monitored', 'critical') and free_beds['general'] > 0:
                    avoidable_specialized += 1
                elif p.acuity == 2 and chosen_bed == 'critical' and free_beds['monitored'] > 0:
                    avoidable_specialized += 1

                slot_idx = beds[chosen_bed].index(None)
                beds[chosen_bed][slot_idx] = p
                free_beds[chosen_bed] -= 1
                p.status = 'ADMITTED'
                p.wait = cur_t - p.arrival_time
                p.assigned_bed = chosen_bed
                admitted_count += 1

                realized_stay = hidden_stays[chosen_bed][p.id]
                heapq.heappush(events, (cur_t + realized_stay, 'DEPARTURE', p.id, chosen_bed, slot_idx))
            else:
                unassigned.append(p)
        queue[:] = unassigned

    while events:
        evt = heapq.heappop(events)
        sim_time = evt[0]
        evt_type = evt[1]

        rem_q = []
        for p in queue:
            if sim_time - p.arrival_time >= MAX_WAIT_CAP:
                p.status = 'REJECTED'
                p.wait = MAX_WAIT_CAP
                rejected_count += 1
            else:
                rem_q.append(p)
        queue = rem_q

        if evt_type == 'ARRIVAL':
            p_id = evt[2]
            p = records[p_id]
            p.status = 'ARRIVED'
            queue.append(p)

            if next_arr_idx < TOTAL_PATIENTS:
                heapq.heappush(events, (arrivals[next_arr_idx], 'ARRIVAL', next_arr_idx))
                next_arr_idx += 1

            attempt_allocations(sim_time)

        elif evt_type == 'DEPARTURE':
            p_id, b_type, slot_idx = evt[2], evt[3], evt[4]
            beds[b_type][slot_idx] = None
            free_beds[b_type] += 1
            records[p_id].status = 'COMPLETED'
            attempt_allocations(sim_time)

    sum_w_wait = sum(p['weight'] * min(p['wait'], MAX_WAIT_CAP) for p in records)
    sum_w = sum(p['weight'] for p in records)
    u_wait = max(0.0, min(1.0, 1.0 - (sum_w_wait / (MAX_WAIT_CAP * sum_w))))

    crit_patients = [p for p in records if p['acuity'] == 3]
    if crit_patients:
        sum_crit_wait = sum(min(p['wait'], MAX_WAIT_CAP) for p in crit_patients)
        u_crit = max(0.0, min(1.0, 1.0 - (sum_crit_wait / (MAX_WAIT_CAP * len(crit_patients)))))
    else:
        u_crit = 1.0

    u_reject = max(0.0, min(1.0, 1.0 - (rejected_count / TOTAL_PATIENTS)))
    u_spec = 1.0 if admitted_count == 0 else max(0.0, min(1.0, 1.0 - (avoidable_specialized / admitted_count)))

    score = (u_wait * 45.0) + (u_crit * 20.0) + (u_reject * 15.0) + (u_spec * 15.0) + 5.0

    return {
        'total_score': score,
        'u_wait': u_wait,
        'u_critical': u_crit,
        'u_reject': u_reject,
        'u_specialized': u_spec,
        'pts_wait': u_wait * 45.0,
        'pts_critical': u_crit * 20.0,
        'pts_reject': u_reject * 15.0,
        'pts_specialized': u_spec * 15.0,
        'avoidable_specialized': avoidable_specialized,
        'rejected_count': rejected_count,
        'admitted_count': admitted_count
    }

if __name__ == '__main__':
    results = run_simulation(SEED)
    print("=" * 60)
    print(f"OFFICIAL BENCHMARK EVALUATION (Seed: {SEED})")
    print("=" * 60)
    print(f"Total Benchmark Score  : {results['total_score']:.2f} / 100.00 pts")
    print(f"Weighted Wait Utility  : {results['pts_wait']:.2f} / 45.0 pts (U = {results['u_wait']:.4f})")
    print(f"Critical Wait Utility  : {results['pts_critical']:.2f} / 20.0 pts (U = {results['u_critical']:.4f})")
    print(f"Rejection Utility      : {results['pts_reject']:.2f} / 15.0 pts (U = {results['u_reject']:.4f})")
    print(f"Specialized Cap. Util. : {results['pts_specialized']:.2f} / 15.0 pts (U = {results['u_specialized']:.4f})")
    print(f"Runtime / Reproduce    : 5.00 / 5.0 pts")
    print("=" * 60)
    print(f"Avoidable Spillovers   : {results['avoidable_specialized']}")
    print(f"Timeout Rejections     : {results['rejected_count']}")
    print(f"Admitted Patients      : {results['admitted_count']}")
