# Bed Pulse — Online Hospital Bed-Allocation & Referral Benchmark

Interactive discrete-event simulation (DES) platform and Markovian decision benchmarking dashboard for real-time hospital bed allocation, emergency triage, and regional transfer routing.

## Project Structure
- `index.html`: Web interface and layout.
- `assets/css/style.css`: Glassmorphic UI styling, animations, and Leaflet overrides.
- `assets/js/`:
  - `simulator.js`: Deterministic PCG64 PRNG and DES engine.
  - `map.js`: Leaflet & Google Maps routing integration.
  - `ai.js`: Gemini 2.5 Flash clinical triage and advisor engine.
  - `canvas.js`: Interactive DNA double-helix background.
  - `app.js`: Main state and DOM controller.
- `scripts/`: Offline Python evaluation script (`online_bed_allocation_policy.py`).

## Deploying to GitHub Pages
1. Initialize git and commit:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
